package com.MohIqbalSyarofAlHafiz5h.negaraasean

object AseanData {
    private val aseanNames = arrayOf(
        "Indonesia",
        "Malaysia",
        "Singapura",
        "Filipina",
        "Vietnam",
        "Thailand",
        "Brunei Darussalam",
        "Mnyanmar",
        "Laos",
        "Kamboja")

    private val aseanDetails = arrayOf (
        "Indonesia merupakan negara terluas di Asia Tenggara dengan luas 5.193.250 kilometer persegi.Indonesia merupakan Negara Kesatuan yang dipimpin oleh seorang presiden dan merayakan hari kemerdekaan setiap tanggal 17 Agustus.Bahasa resmi yang digunakan adalah Bahasa Indonesia dengan rupiah sebagai mata uangnya. Indonesia lalu bergabung menjadi anggota ASEAN pada tanggal 8 Agustus 1967.Bahasa resmi yang digunakan adalah Bahasa Indonesia dengan rupiah sebagai mata uangnya. Indonesia lalu bergabung menjadi anggota ASEAN pada tanggal 8 Agustus 1967.",
        "Malaysia memiliki kepala negara yaitu seorang raja dan perdana menteri adalah kepala pemerintahannya.Negara yang beribukota Kuala Lumpur ini, merayakan kemerdekaannya setiap tanggal 31 Agustus da menggunakan bahasa resmi yaitu, Melayu, Inggris, China dan Tamil dengan mata uang ringgit Malaysia.Wilayah Malaysia memiliki luas 329.847 kilometer persegi dengan jumlah penduduk 33,2 juta jiwa. Lalu, bergabung menjadi anggota ASEAN pada tanggal 8 Agustus 1967.",
        "Singapura merupakan negara di ASEAN dengan luas wilayah 721,5 kilometer prsegi dan kepala negaranya adalah seorang presiden.Singapura beribukota di Singapura, menggunakan Bahasa Inggris, China, Mandarin, Melayu, dan Tamil sebagai bahasa resminya.Hari kemerdekaan Singapura diperingati setiap tanggal 9 Agustus dan bergabung menjadi anggota ASEAN pada tanggal 8 Agustus 1967.",
        "Filipina memilki kepala negara sekaligus kepala pemerintahan yaitu presiden dan beribukota di Manila.Merayakan kemerdekaannya setiap tanggal 12 Agustus dan menggunakan bahasa resmi yaitu bahasa Inggris dan Tagalog.Mata uangnya adalah Kyat dan negara ini memiliki luas wilayah 343.448 kilometer persegi dan Filipina bergabung menjadi anggota ASEAN pada tanggal 8 Agustus 1967.",
        "Negara Vietnam memiliki kepala negara seorang presiden dan perdana menteri sebagai kepala pemerintahan. Negara yang beribukota di Ho Chi Minh ini merayakan hari kemerdekaanya setiap tanggal 5 September.",
        "Thailand memiliki kepala negara seorang raja dan kepala pemerintahan dipimpin oleh Perdana Menteri dan beribukota di Bangkok.Negara ini merayakan hari kemerdekaan setiap tanggal 5 Desember dan menggunakan bahasa resmi yaitu thai dan Baht sebagai mata uangnya.Negara ini memiliki luas wilayah 513.120 kilometer persegi dan bergabung menjadi anggota ASEAN pada tanggal 8 Agustus 1967.",
        "Brunei Darussalam dipimpin oleh seorang Sultan dan ibukotanya adalah Bandar Seri Begawan. Negara ini merayakan kemerdekaanya setiap tanggal 23 Februari.Bahasa yang digunakan adalah bahasa Melayu, Mandarin, dan Bahasa Inggris dan Mata uang Brunei Darussalam adalah Dollar Brunei.Brunei Darussalam memiliki luas 5.765 kilometer persegidan Brunei Darussalam bergabung menjadi anggota ASEAN pada tanggal 8 Januari 1984.",
        "Myanmar memiliki kepala negara dan kepala pemerintahan yang sama, yaitu Presiden. Negara ini beribukota di Nay Pyi dan merayakan hari kemerdekaan setiap tanggal 4 Januari.Bahasa resmi yang digunakan adalah Bahasa Burma dan menggunakan Kyat sebagai mata uang. Myanmar memiliki luas wilayah 676.578 kilometer persegi dan bergabung menjadi anggota ASEAN pada tanggal 23 Juli 1997.",
        "Laos menjadi satu-satunya negara di ASEAN yang enggak memiliki laut dengan luas wilayahnya yaitu 237.955 kilometer persegi.Negara yang beribukota di Vientiane ini menggunakan bahasa resmi yang digunakan adalah Bahasa Lao, Perancis, dan Inggris. Hari kemerdekaan Laos dirayakan setiap tanggal 2 Desember dan bergabung menjadi anggota ASEAN pada tanggal 23 Juli 1997.",
        "Kamboja memiliki pemerintahan yang dipimpin oleh perdana menteri dan Phon Phen adalah ibukotanya.Hari kemerdekaan Kamboja diperingati setiap tanggal 9 November dan memiliki luas wilayah 181.035 kilometer persegi. Kamboja bergabung menjadi anggota ASEAN pada tanggal 30 April 1999.",)


        private val aseanImages = intArrayOf(
        R.drawable.indonesia,
        R.drawable.malaysia,
        R.drawable.singapure,
        R.drawable.filipina,
        R.drawable.vietnam,
        R.drawable.thailand,
        R.drawable.brunei,
        R.drawable.myanmar,
        R.drawable.laos,
        R.drawable.kamboja)


    val listData: ArrayList<Asean>
        get() {
            val list = arrayListOf<Asean>()
            for (position in aseanNames.indices) {
                val Asean = Asean()
                Asean.name = aseanNames [position]
                Asean.detail = aseanDetails [position]
                Asean.photo = aseanImages [position]
                list.add(Asean)
            }
            return list
        }

}
