package com.MohIqbalSyarofAlHafiz5h.negaraasean

data class Asean (
    var name: String = "",
    var detail: String = "",
    var photo: Int = 0
)